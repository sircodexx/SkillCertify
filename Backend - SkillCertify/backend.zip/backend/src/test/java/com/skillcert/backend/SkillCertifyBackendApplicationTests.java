package com.skillcert.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillCertifyBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
